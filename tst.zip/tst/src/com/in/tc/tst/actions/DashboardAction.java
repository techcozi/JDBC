package com.in.tc.tst.actions;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class DashboardAction {
	
	
	public Map tsdbLoad(Map request) {
		System.out.println("DashboardAction.tsdbLoad()");
		HttpServletRequest requestHttp = (HttpServletRequest) request.get("request");
		HttpSession session = requestHttp.getSession(false);
		request.put("fmks", "tsdb");
		
		return request;
	}
	
	
	public Map tscjLoad(Map request) {
		System.out.println("DashboardAction.tscjLoad()");
		HttpServletRequest requestHttp = (HttpServletRequest) request.get("request");
		HttpSession session = requestHttp.getSession(false);
		request.put("fmks", "tscj");
		
		return request;
	}

}
