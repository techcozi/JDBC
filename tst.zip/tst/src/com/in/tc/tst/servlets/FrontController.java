package com.in.tc.tst.servlets;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.in.tc.tst.actions.DashboardAction;
import com.in.tc.tst.util.AppsReader;
import com.in.tc.tst.util.IConstants;

public class FrontController extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	private Properties propsActions = null;

	private Properties propsNav = null;

	public FrontController() {
		super();
	}

	 
	public void init() throws ServletException {
		getActionsProperty();
		getNavigationProperty();
	}
	
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	private void getActionsProperty() {
		propsActions = AppsReader.getFormActions();
	}

	private void getNavigationProperty() {
		propsNav = AppsReader.getFormNavigation();
	}
	
	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");

		HttpSession session = request.getSession(false);
		String actionClass = "";
		Map requestMap = null; 
		Map responseMap = null;
		String actionMethod = "";
		String formId = null;

		try {
			
			 formId = request.getParameter("fmks");
			 actionMethod = request.getParameter("frat");
			 
			 actionMethod=formId+actionMethod;
			 
			 actionClass =  propsActions.getProperty(formId);
			if(null != actionClass) {
				requestMap =  getReuqestDetails(request, response);
				Object actionObject = createActionClassObject(actionClass);
				try{
					responseMap = processForm(actionObject, actionMethod,requestMap);
				}
				catch(Exception e){
					session.invalidate();  
					RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
					rd.forward(request, response);
				}

				if(null != responseMap && responseMap.size() > 0) {

					if(responseMap.get("NEXT_ACTION") != null) {
						getResponseInfo(request,responseMap);
						doGet(request, response);
						return;
					} else {
						getResponseInfo(request,responseMap);
					}

					String resPageId = (String)responseMap.get(IConstants.FORM_ID);
					String page = propsNav.getProperty(resPageId);
					RequestDispatcher rd = request.getRequestDispatcher("/htmls/"+page+IConstants.FORM_EXT);
					rd.forward(request, response);
				}
			}
			
		} catch(Exception e) { 
		
		}
		
	}
		
	private Map processForm(Object sessionEJB, String actionMethod,
			Map mapParm) throws IOException, NamingException, Exception {
		
		Class sessionEJBClass = sessionEJB.getClass();
		Class[] executeParmtypes = new Class[] { Map.class };
		Object[] executeObjArglist = { mapParm };

		Method executeMethod = sessionEJBClass.getMethod(actionMethod, executeParmtypes);
		Map returnObject = (Map) executeMethod.invoke(sessionEJB, executeObjArglist); 

		return returnObject;
	}
	private Object createActionClassObject(String className) {
		
		Object object = null;
		
		if(className != null && !className.equals("")) {
			if(className.equals("dashboardAction")) {
				object = new DashboardAction();
			}
		}
		
		return object;
	}
	
	
	private void getResponseInfo(HttpServletRequest request, Map responseMap) {
		if(null != responseMap && responseMap.size() > 0) {
			Set<String> keys = responseMap.keySet();
			for (String key : keys) {
			 	 request.setAttribute(key, responseMap.get(key));
			}
		}
	}
	
	private Map getReuqestDetails(HttpServletRequest request, HttpServletResponse response) {

		Map requestMap = new HashMap();
		Enumeration en = request.getParameterNames();

		while(en.hasMoreElements()) {
			Object objOri=en.nextElement();
			String param=(String)objOri;
			String value = request.getParameter(param);
			requestMap.put(param, value);
		}

		if(request.getAttribute("NEXT_ACTION") !=null) {
			request.removeAttribute("NEXT_ACTION");
		}  

		requestMap.put("request", request);
		return requestMap;
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		doGet(request,response);
	}

}
