package com.in.tc.tst.db.dao;

import com.in.tc.tst.db.entity.User;

public interface IUserDAO {

	User findByUserId(String userId) throws Exception;
}
