package com.in.tc.tst.db.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.in.tc.tst.db.entity.UserTestActivation;
import com.in.tc.tst.db.services.DBServieImpl;
import com.in.tc.tst.db.services.IDBServie;

public class UserTestActivationDAOImpl implements IUserTestActivationDAO {

private IDBServie dbServie = new DBServieImpl();
	
	public UserTestActivation findByUserId(String userId) throws Exception {
		Connection conn = null;

		String sqlQuery = "Select USERID, PASSWORD, ACTIVE FROM USER_ACTIVATION WHERE USERID='"+userId+"'";
		UserTestActivation  user = null;
		Statement statement = null;
		ResultSet resultSet = null;
		try {

			conn = dbServie.getDBConnection();
			statement = conn.createStatement();
			 resultSet = statement.executeQuery(sqlQuery);

			if(resultSet.next()) {
				user = new UserTestActivation();
				user.setUserId(resultSet.getString(1));
				user.setStartDate(resultSet.getString(2));
				user.setEndDate(resultSet.getString(3));
		    }
			
		} catch (SQLException e) {
			e.printStackTrace();

		} finally {
			
			if(resultSet != null) {
                resultSet.close();
            }

            if (statement != null) {
                statement.close();
            }

            if(conn!=null) {
				conn.close();
			}
		}

		return user;
	}
	
}
