package com.in.tc.tst.db.dao;

public interface IUserTestActivationDAO {

}
