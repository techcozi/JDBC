package com.in.tc.tst.db.services;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import com.in.tc.tst.db.entity.User;

public class DBServieImpl implements IDBServie {

private Connection conn= null;

private static String DRIVER_URL="com.mysql.jdbc.Driver";

private static String DB_CONNECTION_URL="jdbc:mysql://localhost:3306/test";
	
private static String DB_USERNAME="root";

private static String DB_PASSWORD="";


/**
 * getDBConnection: 
 * @return
 */
public Connection getDBConnection() {

	if(conn==null) {
		try {  
			Class.forName(DRIVER_URL);  
			conn =DriverManager.getConnection(DB_CONNECTION_URL,DB_USERNAME,DB_PASSWORD);  
		} catch(Exception e){
			System.out.println(e);
		}  
	}
	return conn;
}	


public static void main(String args[]) {  
	
	try{  
		Class.forName(DRIVER_URL);  
		Connection con =DriverManager.getConnection(DB_CONNECTION_URL,DB_USERNAME,DB_PASSWORD);   

		String sqlQuery = "Select USERID, PASSWORD, ACTIVE FROM USER WHERE ACTIVE ='Y' AND USERID='narendra'";
		User user = null;
		Statement statement = null;
		ResultSet resultSet = null;

		statement = con.createStatement();
		resultSet = statement.executeQuery(sqlQuery);

		if(resultSet.next()) {
			user = new User();
			user.setUserId(resultSet.getString(1));
			user.setPassword(resultSet.getString(2));
		}


		System.out.println("DBServieImpl.main() user "+user);
		con.close();  


	} catch(Exception e){ 
		System.out.println(e);
	}  
}  


}
