package com.in.tc.tst.db.services;

import java.sql.Connection;

public interface IDBServie {

	Connection getDBConnection();
}

