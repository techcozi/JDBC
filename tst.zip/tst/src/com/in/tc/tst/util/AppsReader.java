package com.in.tc.tst.util;


import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class AppsReader {
	
	public static Properties getFormActions() {
		InputStream inStream = null;
		Properties propActionForm = new Properties();

		try {
			inStream = AppsReader.class.getClassLoader().getResourceAsStream("formactions.properties"); //new FileInputStream("formactions.properties");
			propActionForm.load(inStream);

		} catch (IOException io) {
			io.printStackTrace();
		} finally {
			if (inStream != null) {
				try {
					inStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return propActionForm;
	}
	
	
	public static Properties getFormNavigation() {
		InputStream inStream = null;
		Properties propForm = new Properties();

		try {
			inStream = AppsReader.class.getClassLoader().getResourceAsStream("formnavigation.properties");//new FileInputStream("/formnavigation.properties");
			propForm.load(inStream);

		} catch (IOException io) {
			io.printStackTrace();
		} finally {
			if (inStream != null) {
				try {
					inStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return propForm;
	} 
	
	public static void main(String[] args) {
		
		int i =0;
		
		while(i==1) {
			i++;
		}
		
		System.out.println("AppsReader.main() "+i);
		/*

		InputStream inStream = null;
		Properties prop = new Properties();
		
		try {

			inStream = new FileInputStream("resources/actionnav.properties");
			prop.load(inStream);
			// set the properties value
			String d = prop.getProperty("database");

			System.out.println("AppsReader.main() d "+d);

		} catch (IOException io) {
			io.printStackTrace();
		} finally {
			if (inStream != null) {
				try {
					inStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		}
	*/}
}
