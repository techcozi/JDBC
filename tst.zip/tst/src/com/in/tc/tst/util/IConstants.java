package com.in.tc.tst.util;

public interface IConstants {

	String FORM_ID="fmks";
	String FORM_EXT=".jsp";
}
