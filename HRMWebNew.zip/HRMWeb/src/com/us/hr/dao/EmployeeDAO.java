package com.us.hr.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.us.hr.db.DataBaseConnection;
import com.us.hr.entity.User;

public class EmployeeDAO {

	
	/**
	 * 
	 * @return
	 * @throws SQLException
	 */
	public List<User> getAllUser() throws SQLException {
		Connection con = DataBaseConnection.getConnection();
		Statement st = con.createStatement();

		ResultSet resultSet= st.executeQuery("select USERID, PASSWORD, FNAME, LNAME, CREATEBY, ROLE  from USER");
		List<User> list = null;
		
		if(resultSet!=null ) {
			User user = null;
			list = new ArrayList<User>();
			
			while(resultSet.next()){
				 user = new User();
				 user.setUserId(resultSet.getString(1));
				 user.setPassword(resultSet.getString(2));
				 user.setFName(resultSet.getString(3));
				user.setLName(resultSet.getString(4));
				user.setCreateBy(resultSet.getString(5));
				user.setRole(resultSet.getString(6));
				list.add(user);
			}
			
		}
		return list;	
	}
	
	/*
	 * 
	 */
	public User findByUser(String userId, String password) throws Exception {
		System.out.println("EmployeeDAO.findByUser() ++ ");
		
		Connection con = DataBaseConnection.getConnection();
		Statement st;
		User user = null;
		st = con.createStatement();
		String query = "SELECT USERID, PASSWORD, FNAME, LNAME, CREATEBY , ROLE "
				+ " from USER WHERE USERID ='"+userId+"' AND PASSWORD ='"+password+"'";

		ResultSet resultSet= st.executeQuery(query);
		 
		if(resultSet!=null ) {
			while(resultSet.next()){
				 user = new User();
				 user.setUserId(resultSet.getString(1));
				 user.setPassword(resultSet.getString(2));
				 user.setFName(resultSet.getString(3));
				user.setLName(resultSet.getString(4));
				user.setCreateBy(resultSet.getString(5));
				user.setRole(resultSet.getString(6));
				return user;
			}
		}
		
		System.out.println("EmployeeDAO.findByUser() -- ");
		return user;
	}

	/**
	 * 
	 * @param user
	 * @throws Exception
	 */
	public void saveUser(User user) throws Exception {
		
		Connection con = DataBaseConnection.getConnection();
		Statement st;
		st = con.createStatement();
		
		String insertQuery = "insert into USER(USERID, PASSWORD, FNAME, LNAME, CREATEBY, CREATEDT) values('"+
				user.getUserId()+"', '"+user.getPassword()+"','"+user.getFName()+"','"+user.getLName()+"','"+
				user.getCreateBy()+"', sysdate )";
		
		int i = st.executeUpdate(insertQuery);
		
		System.out.println("EmployeeDAO.saveUser() inserted "+i);
		
	}
}
