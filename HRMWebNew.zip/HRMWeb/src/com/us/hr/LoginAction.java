package com.us.hr;

import com.us.hr.dao.EmployeeDAO;
import com.us.hr.entity.User;

public class LoginAction {

	public LoginAction() {
		
	}
	
	
	public User validateUser(String userId, String password) {

		System.out.println("LoginAction.validateUser() ++");
		EmployeeDAO dao = new EmployeeDAO();
		User user = null;

		if(userId!=null && password!=null) {
			try {
				
				user = dao.findByUser(userId, password);
				
				if(null!=user) {
					String role = user.getRole();
					if("ADMIN".equalsIgnoreCase(role)) {
						//......
					}
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		System.out.println("LoginAction.validateUser() ---");
		return user;
	}
		
	
	
}
