package com.us.hr;

import javax.servlet.ServletRequest;
import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;

public class MyServletRequestListener implements ServletRequestListener {

	public MyServletRequestListener() {
	}
	
	public void requestDestroyed(ServletRequestEvent servletRequestEvent) 	{
		ServletRequest request = servletRequestEvent.getServletRequest(); 
		System.out.println("Request Destroyed HRM Application!!!");
	}
	
	
	public void requestInitialized(ServletRequestEvent servletRequestEvent)	{
		ServletRequest request = servletRequestEvent.getServletRequest(); 
		System.out.println("Request initialized HRM Application ..." );
		
	}
}