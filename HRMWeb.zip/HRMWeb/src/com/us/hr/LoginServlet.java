package com.us.hr;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

	
	public class LoginServlet extends HttpServlet {
		private static final long serialVersionUID = 8796051226600816058L;

		@Override
		protected void doPost(HttpServletRequest req, HttpServletResponse response)
				throws ServletException, IOException {
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.println(" userName ..."+req.getParameter("userName"));
			out.println(" \n\n password ..."+req.getParameter("password"));
			ServletContext ctx = getServletContext();
			String userid = ctx.getInitParameter("userid");
			 
			/* 
			PrintWriter out = res.getWriter();
			//Capturing the data from form
			String uname = req.getParameter("uname"); String pwd = req.getParameter("pwd");

			if (uname.equals("admin") && pwd.equals("admin@123")) { 
				RequestDispatcher rd = req.getRequestDispatcher("success.jsp"); rd.forward(req, res);

			} 
			out.println("<font color='red'><b>Invalid credentials</b></font>"); RequestDispatcher rd = req.getRequestDispatcher("login.html"); rd.include(req, res);
		*/}
		
		@Override
		protected void doGet(HttpServletRequest req, HttpServletResponse response)
				throws ServletException, IOException { 
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
			out.println("<HTML>");
			out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
			out.println("  <BODY>");
			out.print("    This is ");
			out.print(this.getClass());
			ServletConfig ctg = getServletConfig();
			String userid = ctg.getInitParameter("configId");
			 
				out.println(" configId ..."+userid);
				//out.println(" \n\n NAME ..."+req.getParameter("name"));
			//}
			out.println("  </BODY>");
			out.println("</HTML>");
			out.flush();
			out.close();
		}
		
		
	}

 
